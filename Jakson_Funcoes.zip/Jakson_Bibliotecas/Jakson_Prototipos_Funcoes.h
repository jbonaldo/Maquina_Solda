#include "stdlib.h"
#include "J_RMS.h" 
#include "Modo_KIR.h" 

extern struct _Rms3Fases Rms;
extern struct _kir Kir;

#pragma CODE_SECTION(AquisitaCanal_1, "ramfuncs");
#pragma CODE_SECTION(Rotina_Teclado, "ramfuncs");

struct _solda {
	Uint16 modo; //0->skt;   1->kir
	Uint16 cont_ciclos;
	Uint16 ciclo_atual;
	Uint16 ciclos_ativos;
	Uint16 ciclos_total;
	Uint16 soldar;
	float I_rms_media;
	
};

extern struct _solda Solda;


struct _disparo_corte_scr {
	Uint16 ticks_min;           
	Uint16 ticks_disparo;		//valor do counter onde os pulsos de disparo do scr sao aplicados
	Uint16 ticks_corta_pulsos;  //valor do counter onde os pulsos de disparo do scr sao retirados
	float Alpha;
	Uint16 SKT;
};

extern struct _disparo_corte_scr Controle_SCRs;
		


extern void AquisitaCanal_1();
void seta_alpha(Uint16 skt);
extern void Rotina_Teclado();
extern void Inicializa_Variaveis();
void Habilita_Pulsos();
void Desabilita_Pulsos();
void Iniciar_Solda();
void Parar_Solda();
void DetecaoZeroPLL();





void Dog_Reset();

//Rotinas SciA
extern void Configura_SciA();
interrupt void sciA_Rx_isr(void);
extern void SciA_TelaInicial();
extern void SciA_Comandos_Hiperterminal();
void RecebePacote(void);
void Reportar_Erro_Ilegal();

//Rotinas SpiA
void SpiA_Configura();
void SpiA_CalibracaoAD();
void SpiA_ConversaoAD(Uint16 *valor_amostrado);
void McBsp_DAC(Uint16 valor, Uint16 enable);
interrupt void spiTxFifoIsr(void);
interrupt void spiRxFifoIsr(void);
extern Uint16 Adc_offset[];


//Rotinas xInt
extern void xInt_Configura();
extern void xInt_ConfiguraIO();
extern interrupt void xInt3_isr(void);

//Rotinas PLL
void InicializaPLL();
float PLL(float tensao);







//Debug
extern float CorrenteSkt[30];   //debeug
extern unsigned int k_ciclos, Namostras[30];	 			//debug