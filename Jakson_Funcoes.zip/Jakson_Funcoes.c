#include "DSP2833x_Device.h"     // Headerfile Include File
#include "DSP2833x_Examples.h"   // Examples Include File
#include "Jakson_Bibliotecas/Jakson_Prototipos_Funcoes.h"  //Prototipo das funcoes programadas pelo usu�rio
#include <math.h>  //debug

//#pragma CODE_SECTION(InitFlash, "ramfuncs");

#define PER_AMOSTRAGEM 	2084
#define NUM_PI 3.141592

Uint16 PerAmostragem = PER_AMOSTRAGEM;		//100Mhz/4/Freq_Amostr.
Uint16 Per120Hz = 52083 + 100;		//Set timer period = 100Mhz/160/120Hz (se deseja freq de 120Hz)
//Uint16 Duty1A = 1000;

//Variaveis utilizadas para DAC e ADC
#define Vmax   1
#define Vbase  1
Uint16 ADC_OffSet = 0;
float corrente_pu = 0;
float tensao_pu = 0;
float Const_ADC_corrente = (float)Vmax*2/4096/Vbase;
float Const_ADC_tensao = (float)Vmax*2/4096/Vbase;

float Const_DAC = (float)Vbase/3.3; //Mudanca de base
float Temp = 0;

struct _solda Solda;
struct _disparo_corte_scr Controle_SCRs;


volatile struct GPADAT_BITS *portA = &GpioDataRegs.GPADAT.bit;  //atalho para acessar a porta A
volatile struct GPBDAT_BITS *portB = &GpioDataRegs.GPBDAT.bit;  //atalho para acessar a porta A

Uint16 valor_amostrado[] = {0, 0};

float Alpha = 0;
Uint16 Alpha_LiMax;
Uint16 Alpha_LiMin;

float temp_dac = 0;
Uint16 ii = 0;

#pragma CODE_SECTION(AquisitaCanal_1, "ramfuncs");
void AquisitaCanal_1()
{
	static float seno1 = 0, seno2 = 0;
	SpiA_ConversaoAD(valor_amostrado);
	corrente_pu = Const_ADC_corrente*((float)valor_amostrado[0]-Adc_offset[0]); //Vo=Vref/4096*(Vi-2047)
	tensao_pu = Const_ADC_tensao*((float)valor_amostrado[1]-Adc_offset[1]); //Vo=Vref/4096*(Vi-2047)
	temp_dac = corrente_pu/Const_ADC_corrente + 2048;


//	McBsp_DAC(ii*4, 2);
//	if(ii++ > 360) ii = 0;
//	McBsp_DAC(tensao_pu*2048 + 2048, 3);
//	McBsp_DAC(corrente_pu*4096 + 2048, 2);
	


/*	//Aquisita Dados do ADC interno
	AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;		//Inicia conversao AD;
	while (AdcRegs.ADCST.bit.INT_SEQ1== 0) {} // Wait for interrup
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;
	//Fim aquisicao interna
	tensao_pu = Const_ADC_tensao*((float)(AdcRegs.ADCRESULT0>>4)-ADC_OffSet); //Vo=Vref/4096*(Vi-2047)
*/
	seno2 = PLL(tensao_pu);
	if( (seno2>=0 && seno1<0) || (seno2<=0 && seno1>0))
	{
		DetecaoZeroPLL();
	}
	seno1 = seno2;
	EPwm6Regs.CMPA.half.CMPA = (seno2 * 1150) + 1150; //debug


	
	Rms.Tensao.in = tensao_pu;
	Rms.Tensao.Calcular(&Rms.Tensao);
	if( Rms.Tensao.i > Rms.Tensao.NAmostras )  
		Rms.Tensao.RMS120Hz(&Rms.Tensao)	;
	
	if(Solda.soldar) 
	{
		Rms.FaseA.in = corrente_pu;
		Temp = Rms.FaseA.Calcular(&Rms.FaseA);
	//	portA->GPIO23 = 0;						  //Inicia conversao
	//	SpiA_DAC(Temp*100);
	//	portA->GPIO23 = 1;						  //Termina conversao
	}	
}

#pragma CODE_SECTION(seta_alpha, "ramfuncs");
void seta_alpha(Uint16 skt)
{
	Uint16 temp;
	float alpha;

	if(skt > 999) skt = 999;

	alpha = (float) 120*((float)(999-skt)/999) + 30;
	
	temp = (Uint16) Per120Hz*(alpha/180);
	if( temp>Alpha_LiMax )
	{
		Controle_SCRs.ticks_disparo = Alpha_LiMax;
		//EPwm1Regs.CMPA.half.CMPA = Alpha_LiMax;
	}
	else
		if( temp<Alpha_LiMin )
		{
			Controle_SCRs.ticks_disparo = Alpha_LiMin;
		//	EPwm1Regs.CMPA.half.CMPA = Alpha_LiMin;
		}
		else {
			Controle_SCRs.ticks_disparo = temp;	
		//	EPwm1Regs.CMPA.half.CMPA = temp;
		}

	Controle_SCRs.Alpha = alpha;

	EPwm1Regs.CMPA.half.CMPA =  Controle_SCRs.ticks_disparo;
	EPwm2Regs.CMPA.half.CMPA =  Controle_SCRs.ticks_disparo;
	EPwm3Regs.CMPA.half.CMPA =  Controle_SCRs.ticks_disparo;
}


#pragma CODE_SECTION(Habilita_Pulsos, "ramfuncs");
void Habilita_Pulsos()
{
	EPwm1Regs.ETSEL.bit.INTEN = 1;		   // Enable INT
	EPwm1Regs.AQCTLA.bit.CAU = AQ_SET;   //Habilita Pulsos FaseA (PWM1 dispara PWM4)
	EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event  
/*
	EPwm2Regs.ETSEL.bit.INTEN = 1;		   // Enable INT
	EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;   //Habilita Pulsos FaseA (PWM1 dispara PWM4)
	EPwm2Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event  


	EPwm3Regs.ETSEL.bit.INTEN = 1;		   // Enable INT
	EPwm3Regs.AQCTLA.bit.CAU = AQ_SET;   //Habilita Pulsos FaseA (PWM1 dispara PWM4)
	EPwm3Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event  
*/
}

#pragma CODE_SECTION(Desabilita_Pulsos, "ramfuncs");
void Desabilita_Pulsos()
{
	EPwm1Regs.ETSEL.bit.INTEN = 0;		    // Disanable INT
	EPwm1Regs.ETPS.bit.INTPRD = ET_DISABLE; // Nao gera mais interrupcoes
	EPwm4Regs.AQCTLA.bit.ZRO = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM4)
	EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM1 dispara PWM4)
/*
	EPwm2Regs.ETSEL.bit.INTEN = 0;		    // Disanable INT
	EPwm2Regs.ETPS.bit.INTPRD = ET_DISABLE; // Nao gera mais interrupcoes
	EPwm5Regs.AQCTLA.bit.ZRO = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM4)
	EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM1 dispara PWM4)

	EPwm3Regs.ETSEL.bit.INTEN = 0;		    // Disanable INT
	EPwm3Regs.ETPS.bit.INTPRD = ET_DISABLE; // Nao gera mais interrupcoes
	EPwm6Regs.AQCTLA.bit.ZRO = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM4)
	EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;    //Desabilita Pulsos FaseA (PWM1 dispara PWM4)
*/
}

void Parar_Solda()
{
	Desabilita_Pulsos();
}

void Iniciar_Solda()
{
	Habilita_Pulsos();
}

void DetecaoZeroPLL()
{
	//Pulso de detecao do zero da fase1
	GpioDataRegs.GPBTOGGLE.bit.GPIO61 = 1;	//mostra o instante em q ocorreu o sincronismo

	if(EPwm1Regs.TBCTR > 15000) 
	{
		EPwm1Regs.ETCLR.bit.INT = 1;          	// Limpa os pedidos de interrupcao que por ventura estiverem pendentes 
		EPwm2Regs.ETCLR.bit.INT = 1;          	// Limpa os pedidos de interrupcao que por ventura estiverem pendentes 
		EPwm3Regs.ETCLR.bit.INT = 1;          	// Limpa os pedidos de interrupcao que por ventura estiverem pendentes 
		PieCtrlRegs.PIEIFR3.bit.INTx1 = 0;
		EPwm1Regs.TBCTL.bit.SWFSYNC = 1;		//For�a sincronizacao do PWM1 (Zera o counter)
	}

	if(Solda.soldar)
	{
		EPwm1Regs.CMPA.half.CMPA =  Controle_SCRs.ticks_min;
		Habilita_Pulsos();
	}

	Rms.Tensao.RMS120Hz(&Rms.Tensao);
}

void Rotina_Teclado()
{
	if(portA->GPIO12) 
		if( EPwm1Regs.CMPA.half.CMPA < Alpha_LiMax )
			EPwm1Regs.CMPA.half.CMPA += 1;

	if(portA->GPIO15)  
		if( EPwm1Regs.CMPA.half.CMPA > Alpha_LiMin )
			EPwm1Regs.CMPA.half.CMPA -= 1;

	if(portA->GPIO24)  //inibe os pulsos p/ os SCRs
		EPwm1Regs.ETSEL.bit.INTEN = !EPwm1Regs.ETSEL.bit.INTEN;
	

}

void Inicializa_Variaveis()
{
	Alpha_LiMax = Per120Hz * (float)(180-30)/180;  	//CMPA * (grau/180)
	Alpha_LiMin = Per120Hz * (float)(180-160)/180;		//CMPA * (grau/180)

	Solda.modo = 0;		//0->skt;   1->kir;
	Solda.ciclos_ativos = 10;
	Solda.ciclos_total = 1000;
	Solda.ciclo_atual = 0;
	Solda.soldar = 0;
	Alpha = 120;

	Controle_SCRs.ticks_corta_pulsos = 50500; //Termina os pulsos aprox 140us antes do cruzamento por zero
	Controle_SCRs.ticks_min = 8680;   //Corresponde a 30 graus

	Rms.Inicializar(&Rms);
	Rms.FaseA.fator_escala = (float)26.625;	//Fator que multiplicado por Irms resulta em kA
	Rms.Tensao.fator_escala = (float)1;	//Fator que multiplicado por Irms resulta em kA
	Rms.FaseA.Inicializar(&Rms.FaseA);
//	Rms.FaseB.Inicializar(&Rms.FaseB);
//	Rms.FaseC.Inicializar(&Rms.FaseC);

	Kir.InicializarVariaveis(&Kir);

	InicializaPLL();
}
